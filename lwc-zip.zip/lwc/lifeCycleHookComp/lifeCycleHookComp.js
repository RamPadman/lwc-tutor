import { LightningElement,api } from 'lwc';

export default class LifeCycleHookComp extends LightningElement {
    initVar;
    consVar;
    renderVar;
    @api publicProperty;
    constructor() {
        super();
        this.consVar ='In Constructor';
        let customVar = 'Hello';
        console.log(customVar);
        console.log(this.consVar);
    }
    connectedCallback() {
        this.initVar = 'In connected call back';
        console.log('in connected callback');
        //console.log(this.querySelectorAll('p').length);
    }
    renderedCallback() {
        this.renderVar = 'In rendered call back';
        console.log('in render calback');
        console.log(this.template.querySelector('lightning-button'));
    }
}