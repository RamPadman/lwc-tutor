import { LightningElement,api } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import CONTACT_OBJECT from '@salesforce/schema/Contact';
import NAME_FIELD from '@salesforce/schema/Contact.LastName';
import FNAME_FIELD from '@salesforce/schema/Contact.FirstName';
import ACCID_FIELD from '@salesforce/schema/Contact.AccountId';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class ContactEdit extends LightningElement {
    @api recordId;
    @api objectApiName; 
    inputVal = '';
    customCont ;
    fName = '';
    lName = '';

    handleChange(event) {
      if(event.target.label =='First Name') {
        this.fName = event.target.value;
      } else if (event.target.label =='Last Name') {
        this.lName = event.target.value;
      }
    }
    createContact() {
      const fields = {};
      fields[NAME_FIELD.fieldApiName] = this.lName;
      fields[FNAME_FIELD.fieldApiName] = this.fName;
      fields[ACCID_FIELD.fieldApiName] = this.recordId;
      const recordInput = { apiName: CONTACT_OBJECT.objectApiName, fields };
      createRecord(recordInput)
          .then(contact => {
              console.log(contact);
              this.dispatchEvent(
                  new ShowToastEvent({
                      title: 'Success',
                      message: 'Contact created ',
                      variant: 'success',
                  }),
              );
          })
          .catch(error => {
              this.dispatchEvent(
                  new ShowToastEvent({
                      title: 'Error creating record',
                      message: error.body.message,
                      variant: 'error',
                  }),
              );
          });
  }
}