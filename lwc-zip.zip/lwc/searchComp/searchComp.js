import { LightningElement,wire,api } from 'lwc';
import findContacts from '@salesforce/apex/ContactController.findContacts';
import { NavigationMixin } from 'lightning/navigation';
const DELAY = 300;
export default class SearchComp extends NavigationMixin(LightningElement) {
    searchKey = '';
    contacts;
    error;
    @api tabName ='Contacts';
    @wire(findContacts, { searchKey: '$searchKey' })
    contacts;
    displayText = false;
    connectedCallback() {
        //imperative call to apex
        /*findContacts({searchKey :this.searchKey}).then(result=>{
            this.contacts = result;
        })*/
    }
   /* getContacts() {
        findContacts({searchKey :this.searchKey}).then(result=>{
            this.contacts = result;
        })
    }*/
    handleKeyChange(event) {
        this.searchKey = event.target.value;
        this.displayText = true;
       // window.clearTimeout(this.delayTimeout);
       /* this.delayTimeout = setTimeout(() => {
           
        }, DELAY);*/
    }
    /*handleSearch() {
        findContacts({ searchKey: this.searchKey })
            .then((result) => {
                this.contacts = result;
                this.error = undefined;
            })
            .catch((error) => {
                this.error = error;
                this.contacts = undefined;
            });
    }*/
    handleClick(evt) {
        const accountHomePageRef = {
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Account',
                actionName: 'home',
                target:'_blank'
            },
        };
        //this[NavigationMixin.GenerateUrl](accountHomePageRef)
        //    .then(url => window.open(url));
        //evt.preventDefault();
        //evt.stopPropagation();
        // Navigate to the Account Home page.
        
      // this[NavigationMixin.Navigate](accountHomePageRef);

       //---US a
       this[NavigationMixin.Navigate]({
        type: 'standard__recordPage',
        attributes: {
            recordId: '5005I000004SXXcQAO',
                objectApiName: 'Case', // objectApiName is optional
                actionName: 'view'
        }
    });
    }
}