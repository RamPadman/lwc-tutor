import { LightningElement,api } from 'lwc';

export default class QuerySelectorComp extends LightningElement {
    greeting = 'Chennai';
    inputVal = 'Ram Ram'
    numVal = 7;
    @api flag = false;
    updateValue() {
        //update input value
        const currInput = this.template.querySelector('lightning-input');
        console.log(currInput.value);
        console.log(currInput.label);
        currInput.value = 'Sant Anan';
        this.inputVal = currInput.value;
        console.log(this.inputVal);
        //check span values
        //[1,2,3,4]
        const arrList = this.template.querySelectorAll('lightning-input');
        console.log(this.template.querySelectorAll('span').length);
        if(arrList.length > 0) {
            //for each loop
            arrList.forEach(element => {
                if(element.type === 'Number'){
                    element.value = 10;
                }
            });
        }
        
    }
   @api childMethod() {
        console.log('api');
    }
}