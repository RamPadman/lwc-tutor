import { LightningElement,api } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import ACCT_FIELD from '@salesforce/schema/Opportunity.AccountId';
export default class LtngViewRecDetails extends LightningElement {
   recordId = getFieldValue(ACCT_FIELD);
   @api recordId;
}