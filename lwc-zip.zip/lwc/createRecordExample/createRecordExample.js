import { LightningElement } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import WEBSITE_FIELD from '@salesforce/schema/Account.Website';
export default class CreateRecordExample extends LightningElement {
    accountId;
    name = '';
    website = '';
    handleNameChange(event) {
        this.accountId = undefined;
        if(event.target.label === 'Name') {
            this.name = event.target.value;
        }
        else if(event.target.label === 'website') {
            this.website = event.target.value;
        }
    }
    createAccount() {
        const fields = {};
        fields[NAME_FIELD.fieldApiName] = this.name;
        fields[WEBSITE_FIELD.fieldApiName] = this.website;
        const recordInput = { apiName: ACCOUNT_OBJECT.objectApiName, fields };
        createRecord(recordInput)
            .then(acct => {
                this.accountId = acct.id;
                //firing toast event
                this.dispatchEvent(
                    //creating toast event
                    this.fireToastEvent('Success','Santosh created Account','success')
                );
            })
            .catch(error => {
                this.dispatchEvent(
                    this.fireToastEvent('Error creating record',error.body.message,'error')
                );
            });
    }
    fireToastEvent(title,message,variant) {
        const showTstEvt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        return showTstEvt;
    }
    
}