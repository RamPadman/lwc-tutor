import { LightningElement } from 'lwc';
import pubsub from 'c/pubsub' ; 
import BTN_CLICK from '@salesforce/label/c.Button_To_Send_Msg';
import SECOND_LABEL from '@salesforce/label/c.Some_Custom_Label';
import CUSTOM_LOGO from '@salesforce/resourceUrl/TK_Logo';
export default class PublisherComp extends LightningElement {
    imageURL = CUSTOM_LOGO;
    label = {BTN_CLICK,SECOND_LABEL};
    handleClick(){
        let message = {
            "name" : 'Hello Santosh'
        }
        pubsub.fire('santoshEvent', message);
    }
}