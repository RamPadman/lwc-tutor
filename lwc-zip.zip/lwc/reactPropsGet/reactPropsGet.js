import { LightningElement } from 'lwc';

export default class ReactPropsGet extends LightningElement {
    /*firstName = '';
    lastName = '';*/
    firstNumber = 5;
    secondNumber = 0;
    //var 
    //let,const,var 
    //let integer =0;
    handleChange(event) {
        let firstNumber = 0;
        var firstNumb = 0;
        const field = event.target.name;
        if(field === 'firstNumber') {
            this.firstNumber = event.target.value;
        } else if (field === 'secondNumber') {
            this.secondNumber = event.target.value;
        }
        
    }
    
    getName() {
        const init = 0;
        let arr;
    }
    
    get sumOfTwoNumbers() {
        //this.getName();
        return Number(this.firstNumber)+Number(this.secondNumber);
    }
     
}