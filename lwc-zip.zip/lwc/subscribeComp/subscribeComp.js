import { LightningElement } from 'lwc';
import pubsub from 'c/pubsub' ; 

export default class SubscribeComp extends LightningElement {
    localMessage;
    connectedCallback(){
        
        this.register();
    }
    register(){ 
        pubsub.register('santoshEvent', this.handleEvent.bind(this)); 
    }
    handleEvent(messageFromEvt){
        //window.console.log('event handled ',messageFromEvt);
        this.localMessage = messageFromEvt ? JSON.stringify(messageFromEvt) : 'no message payload';
    }
}