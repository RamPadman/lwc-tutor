import { LightningElement,wire } from 'lwc';
import {MessageContext,publish} from 'lightning/messageService';
import lmsChannel from "@salesforce/messageChannel/MyMessageChannel__c";
export default class LmsPublisher extends LightningElement {
    msg;
    // Wired message Context
    @wire(MessageContext)
    context;
    handleChange(event) {
        this.msg = event.detail.value;
    }
 
    handlePublish() {
            let payload = {
                source: "LWC",
                messageBody: this.msg
            };
            publish(this.context, lmsChannel, payload);  
    }
}