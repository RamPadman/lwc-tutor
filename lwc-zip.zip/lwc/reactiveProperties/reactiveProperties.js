import { LightningElement } from 'lwc';

export default class ReactiveProperties extends LightningElement {
    greeting = 'Santosh';

    handleChange(event) {
        this.greeting = event.target.value;
    }
    callChildMeth(){
        const childComp = this.template.querySelector('c-query-selector-comp');
        if(childComp) {
            childComp.flag = !childComp.flag;
            childComp.childMethod();
        }

    }
}