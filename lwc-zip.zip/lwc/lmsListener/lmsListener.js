import { LightningElement } from 'lwc';
import {createMessageContext, APPLICATION_SCOPE, subscribe} from 'lightning/messageService';
import POVMC from "@salesforce/messageChannel/MyMessageChannel__c";
export default class LmsListener extends LightningElement {
    receivedMessage = '';
    subscription = null;
    context;
    handleSubscribe() { 
        if (this.subscription) {
            return;
        }
        this.context = createMessageContext();
        this.subscription = subscribe(this.context, POVMC, (message) => {
            this.handleMessage(message);
        }, {scope: APPLICATION_SCOPE});
    }
    handleMessage(event) {
        if (event) {
            this.receivedMessage = 'Message: ' + event.messageBody + '.\n \n Sent From: ' + event.source;
        }
    }
}